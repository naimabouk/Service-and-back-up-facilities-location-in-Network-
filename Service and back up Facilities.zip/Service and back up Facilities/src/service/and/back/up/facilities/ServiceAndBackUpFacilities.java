
package service.and.back.up.facilities;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;


public class ServiceAndBackUpFacilities {
    //	[][] Lire_Matrice("file/////////////test.txt" , 3)


	public static double[][] readfile(String path) {
		BufferedReader br = null;
	        FileReader fr = null;
	        
	        
	        try {
				fr = new FileReader(path);
				br = new BufferedReader(fr);
				ArrayList<String> lines = new ArrayList();
				String tmp;
				while((tmp = br.readLine()) != null)
					lines.add(tmp);
				
				int colNum = new Integer(lines.get(0)).intValue();
				double[][] mat = new double[lines.size()-1][colNum];
				

				for(int i =0;i<mat.length;i++) {
					mat[i][0] = new Integer(lines.get(i+1).split(",")[0]).doubleValue() ;
					mat[i][1] = new Integer(lines.get(i+1).split(",")[1]).doubleValue();
					mat[i][2] = new Integer(lines.get(i+1).split(",")[2]).doubleValue();
				}
                                	return mat;
				
				
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	        return null;
	}
    

    
    public static void main(String[] args)throws IOException  {
          double startTime = System.currentTimeMillis();//start run time 
        // Initialize the graph
		Node[] nodes = { new Node("1", 1), new Node("2", 4), new Node("3", 3), new Node("4", 5), new Node("5", 2),
				new Node("6", 1), new Node("7", 7), new Node("8", 1), new Node("9", 4), new Node("10", 6),
				new Node("11", 3), new Node("12", 3), new Node("13", 1) };
	
		String exemple0= "C:\\Users\\khwira\\Documents\\NetBeansProjects\\Service and back up Facilities\\src\\service\\and\\back\\up\\facilities\\edges";
		double[][] mm = readfile(exemple0);
		
		Graph graph = new Graph(nodes.length);
		
		for (int i = 0; i < graph.V(); i++) {
			graph.setLabel(i, nodes[i]);
		}

		for(int i=0;i<mm.length;++i) 
		graph.addEdge((int) mm[i][0],(int) mm[i][1],(int) mm[i][2]);
	   
		System.out.println(graph);
		System.out.println();
              
		// Placing the facilities
		ArrayList<Facility> facilities = new ArrayList<>();

		ArrayList<Integer> tipNodes = graph.getTipNodes();
	
		while (!tipNodes.isEmpty()) {

			int tipNode = tipNodes.get(0);

			int nextNode = graph.getAdj(tipNode).get(0);

			Facility facility = new Facility("x" + (facilities.size() + 1), graph.getLabel(tipNode),
			graph.getLabel(nextNode));

			double[] dist = graph.Dijkstra(tipNode);
			for (int i = 0; i < dist.length; i++)
				if (dist[i] - facility.getDistNode() <= graph.getLabel(i).getMaxDist()) {
					facility.addNode(graph.getLabel(i));
					graph.removeNode(i);
				}

			facilities.add(facility);
			tipNodes = graph.getTipNodes();
		}
		for (Facility f : facilities)
			System.out.println(f);
		
		// Initialize the graphf
		Abstraction_Facility [] facs = { new Abstraction_Facility("1", 7), new Abstraction_Facility("2", 7), new Abstraction_Facility ("3",7), new Abstraction_Facility("4",7), new Abstraction_Facility("5",7),
				new Abstraction_Facility("6", 7) };
	
		
		double[][] ff = readfile("C:\\Users\\khwira\\Documents\\NetBeansProjects\\Service and back up Facilities\\src\\service\\and\\back\\up\\facilities\\edges");
		
		Graphf graphf = new Graphf(facs.length);
		
		for (int i = 0; i < graphf.F(); i++) {
			graphf.setLabelf(i, facs [i]);
		}

		for(int i=0;i<ff.length;i++) 
                graphf.addEdges((int) ff[i][0],(int) ff[i][1],(int) ff[i][2]);
	   
		System.out.println(graphf);
		System.out.println();

	
		// Placing the back up 
		ArrayList<Back_up> backup = new ArrayList<>();
		
		ArrayList<Integer>tipFacilities =graphf. getFacilities();
		
		while (!tipFacilities.isEmpty()) {
			
			int tipFacilitie = tipFacilities.get(0);
			int nextFacilitie = graph.getAdj(tipFacilitie).get(0);
			Back_up backupp = new Back_up ("X"+(backup.size()+ 6),graphf.getLabelf(tipFacilitie),
					graphf.getLabelf(nextFacilitie));
			
		
			double[] distf = graphf.Dijkstraa(tipFacilitie);
			for (int i = 0; i < distf.length; i++)
				if (distf[i] - backupp.getDistFacility() <= graphf.getLabelf(i).getMaxDist()) {
					backupp.addFacility(graphf.getLabelf(i));
					graphf.removeFacility(i);
				}
			backup.add(backupp);
			tipFacilities = graphf.getFacilities();
		  }
		    for (Back_up f :backup)
			System.out.println(f);

                    
                    double stopTime = System.currentTimeMillis(); //stop runtime
                    System.out.println("run  time: "+(stopTime - startTime));//display
		}
	
  
    }
    

