
package service.and.back.up.facilities;
import java.util.ArrayList;

public class Graph {
    private double[][] matrix;
	//private double [][]matrixx;
	private Node[] labels;
	//private   Abstraction_Facility [] labelss; 
	private  int V;
       // private  int  F; 
	private int E;
	//private int G ;
     // int d;
	public Graph( int v) {
		 
		V =  v;
		matrix = new double[V][V];
		labels = new Node[V];
	}
	/* public Graph (int f,int d) {
		 this.d=d;
		F = f;
		matrixx = new double[ F][ F];
		labelss = new  Abstraction_Facility[F];
	}*/
	

	public int V() {
		return V;
	}

	public int E() {
		return E;
	}
      /*   public int F() {
               	return F;
        }
         public int G() {
                return G ;
        } */
	public void setLabel(int vertex, Node  label) {
		labels[vertex] = label;
	}

	public Node getLabel(int vertex) {
		return labels[vertex];
	}

	/*public void setLabelf(int fac,   Abstraction_Facility labell) {
		labelss[fac] = labell;
	}

	public   Abstraction_Facility getLabelf(int fac) {
		return labelss[fac];
	}
*/
	public void addEdge(int node1, int node2, double w) {
		matrix[node1][node2] = w;
		matrix[node2][node1] = w;
		E++;
	}

	/*public void addEdges(int fac1 , int fac2, double y) {
		matrixx[fac1][fac2] = y;
		matrixx[fac2][fac1] = y;
		G++;
	}
*/
	public boolean isEdge(int node1, int node2) {
		return matrix[node1][node2] > 0;
	}
	//public boolean isEdgef(int fac1, int fac2) {
	//	return matrix[fac1][fac2] > 0;
	//}
	
	public void removeEdge(int node1, int node2) {
		matrix[node1][node2] = 0;
		matrix[node2][node1] = 0;
		E--;
	}


	//public void removeEdgef(int fac1, int fac2) {
		//matrix[fac1][fac2] = 0;
		//matrix[fac2][fac1] = 0;
		//G--;
	//}

	public double getWeight(int node1, int node2) {
		return matrix[node1][node2];
	}
	/*public double getWeightf(int fac1, int fac2) {
		return matrixx[fac1][fac2];
	}
*/
	public void removeNode(int node) {
		for (int i = 0; i < V; i++) {
			matrix[node][i] = 0;
			matrix[i][node] = 0;
		}
		
	}	
	/*public void removeFacility(int fac) {
		for (int i = 0; i < F; i++) {
			matrixx[fac][i] = 0;
			matrixx[i][fac] = 0;
		}
	}*/
	
	

	public ArrayList<Integer> getAdj(int node) {
		ArrayList<Integer> list = new ArrayList<>();
		for (int i = 0; i < V(); i++)
			if (matrix[node][i] > 0)
				list.add(i);
		return list;
	}
	/*public ArrayList<Integer> getAdjf(int fac) {
		ArrayList<Integer> list = new ArrayList<>();
		for (int i = 0; i < F(); i++)
			if (matrixx[fac][i] > 0)
				list.add(i);
		return list;
	}*/

	public ArrayList<Integer> getTipNodes() {
		ArrayList<Integer> list = new ArrayList<>();
		int count;
		for (int i = 0; i < V(); i++) {
			count = 0;
			for (int j = 0; j < V() && count <= 1; j++)
				if (matrix[i][j] > 0)
					count++;

			if (count == 1)
				list.add(i);
		}
		return list;
	}
	/*public ArrayList<Integer> getFacilities() {
		ArrayList<Integer> list = new ArrayList<>();
		int count;
		for (int i = 0; i < F(); i++) {
			count = 0;
			for (int j = 0; j < F() && count <= 1; j++)
				if (matrixx[i][j] > 0)
					count++;

			if (count == 1)
				list.add(i);
		}
		return list;
	}*/


	
	public double[] Dijkstra(int src) {
		Boolean sptSet[] = new Boolean[V];
		double dist[] = new double[V];

		for (int i = 0; i < V; i++) {
			dist[i] = Double.POSITIVE_INFINITY;
			sptSet[i] = false;
		}

		dist[src] = 0;

		for (int count = 0; count < V - 1; count++) {
			int u = minDistance(dist, sptSet);
			sptSet[u] = true;
			for (int v = 0; v < V; v++)
				if (!sptSet[v] && matrix[u][v] != 0 && dist[u] != Double.POSITIVE_INFINITY
						&& dist[u] + matrix[u][v] < dist[v])
					dist[v] = dist[u] + matrix[u][v];
		}
		return dist;
	}

	private int minDistance(double dist[], Boolean sptSet[]) {
		double min = Double.POSITIVE_INFINITY;
		int minIndex = -1;

		for (int v = 0; v < V; v++)
			if (sptSet[v] == false && dist[v] <= min) {
				min = dist[v];
				minIndex = v;
			}
		return minIndex;
	}
	/*public double[] Dijkstraa(int src2) {
		Boolean sptSet[] = new Boolean[F];
		double distf[] = new double[F];

		for (int i = 0; i < F; i++) {
			distf[i] = Double.POSITIVE_INFINITY;
			sptSet[i] = false;
		}

		distf[src2] = 0;

		for (int count = 0; count < F - 1; count++) {
			int u = minDistance(distf, sptSet);
			sptSet[u] = true;
			for (int v = 0; v < F; v++)
				if (!sptSet[v] && matrixx[u][v] != 0 && distf[u] != Double.POSITIVE_INFINITY
						&& distf[u] + matrixx[u][v] < distf[v])
					distf[v] = distf[u] + matrixx[u][v];
		}
		return distf;
	}

	private int minDistancee(double distf[], Boolean sptSet[]) {
		double min = Double.POSITIVE_INFINITY;
		int minIndex = -1;

		for (int v = 0; v < F; v++)
			if (sptSet[v] == false && distf[v] <= min) {
				min = distf[v];
				minIndex = v;
			}
		return minIndex;
	}*/
   //affichage 
	@Override
	public String toString() {
		StringBuilder s = new StringBuilder();
		s.append("vertex: " + V() + " , Edges : " + E());
		for (int i = 0; i < V(); i++) {
			s.append("\n" + labels[i].getName() + " => ");
			for (int j = 0; j < V(); j++)
				if (matrix[i][j] > 0)
					s.append("[" + labels[j].getName() + " , " + matrix[i][j] + "] ");
		}
		return s.toString();
	}
    
    
    
    
    
}
