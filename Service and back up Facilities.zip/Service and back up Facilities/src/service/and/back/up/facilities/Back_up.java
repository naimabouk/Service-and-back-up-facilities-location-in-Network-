

package service.and.back.up.facilities;

import java.util.ArrayList;
public class Back_up {
    	private String  name;
	private Abstraction_Facility fac1;
	private  Abstraction_Facility fac2;
	 private ArrayList< Abstraction_Facility>coverFacilities;
	
	 public Back_up (String name ,Abstraction_Facility fac1,Abstraction_Facility fac2) {
		    this.name=name;
                    this.fac1=fac1;
                    this.fac2=fac2;
			
			coverFacilities=new ArrayList<>();
	 }
				public String getName() {
					return name;
				}

				public void setName(String name) {
					this.name = name;
				}
				public  Abstraction_Facility getFacility() {
					return fac1;
				}

				public void setFacility( Abstraction_Facility fac) {
					this.fac1 = fac;
				}
				public double getDistFacility() {
					return fac1.getMaxDist();
				}

		        public void addFacility(  Abstraction_Facility f) {
			    coverFacilities.add(f);
		        }
		        
	            public ArrayList<  Abstraction_Facility> getcoverFacilities() {
			    return coverFacilities;
		        }

	
	@Override
	public String toString() {
		StringBuilder s = new StringBuilder();
		s.append("Facility " + getName() + ", on edge (" 
				+ ") from distance of "   + " \n");
		s.append("\t Covered facilities are ");
		for (  Abstraction_Facility f : coverFacilities)
			s.append(f.getName() + " ");
		return s.toString();
	}

    
    
}
