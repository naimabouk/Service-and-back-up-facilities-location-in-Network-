
package service.and.back.up.facilities;
import java.util.ArrayList;

public class Graphf {
    
        private double [][]matrixx;
	private   Abstraction_Facility [] labelss; 
        private  int  F; 
        private int G ;
  
	
	public Graphf (int f) {
		 
		F = f;
		matrixx = new double[ F][ F];
		labelss = new  Abstraction_Facility[F];
	}

         public int F() {
               	return F;
        }
         public int G() {
                return G ;
         }
	

	

	public void setLabelf(int fac,   Abstraction_Facility labell) {
		labelss[fac] = labell;
	}

	public   Abstraction_Facility getLabelf(int fac) {
		return labelss[fac];
	}

	

	public void addEdges(int facc1 , int facc2, double y) {
		matrixx[facc1][facc2] = y;
		matrixx[facc2][facc1] = y;
		G++;
	}

	
	public boolean isEdgef(int fac1, int fac2) {
		return matrixx[fac1][fac2] > 0;
	}
	
	


	public void removeEdgef(int fac1, int fac2) {
		matrixx[fac1][fac2] = 0;
		matrixx[fac2][fac1] = 0;
		G--;
	}

	public double getWeightf(int fac1, int fac2) {
		return matrixx[fac1][fac2];
	}

	
		
		
	public void removeFacility(int fac) {
		for (int i = 0; i < F; i++) {
			matrixx[fac][i] = 0;
			matrixx[i][fac] = 0;
		}
	}
	
	

	
	public ArrayList<Integer> getAdjf(int fac) {
		ArrayList<Integer> list = new ArrayList<>();
		for (int i = 0; i < F(); i++)
			if (matrixx[fac][i] > 0)
				list.add(i);
		return list;
	}

	
	public ArrayList<Integer> getFacilities() {
		ArrayList<Integer> list = new ArrayList<>();
		int count;
		for (int i = 0; i < F(); i++) {
			count = 0;
			for (int j = 0; j < F() && count <= 1; j++)
				if (matrixx[i][j] > 0)
					count++;

			if (count == 1)
				list.add(i);
		}
		return list;
	}


	
	
	public double[] Dijkstraa(int src2) {
		Boolean sptSet[] = new Boolean[F];
		double distf[] = new double[F];

		for (int i = 0; i < F; i++) {
			distf[i] = Double.POSITIVE_INFINITY;
			sptSet[i] = false;
		}

		distf[src2] = 0;

		for (int count = 0; count < F - 1; count++) {
			int u = minDistancee(distf, sptSet);
			sptSet[u] = true;
			for (int v = 0; v < F; v++)
				if (!sptSet[v] && matrixx[u][v] != 0 && distf[u] != Double.POSITIVE_INFINITY
						&& distf[u] + matrixx[u][v] < distf[v])
					distf[v] = distf[u] + matrixx[u][v];
		}
		return distf;
	}

	private int minDistancee(double distf[], Boolean sptSet[]) {
		double min = Double.POSITIVE_INFINITY;
		int minIndex = -1;

		for (int v = 0; v < F; v++)
			if (sptSet[v] == false && distf[v] <= min) {
				min = distf[v];
				minIndex = v;
			}
		return minIndex;
	}
   //affichage 
	@Override
	public String toString() {
		StringBuilder s = new StringBuilder();
		s.append("vertex: " + F() + " , Edges : " + G());
		for (int i = 0; i < F(); i++) {
			s.append("\n" + labelss[i].getName() + " => ");
			for (int j = 0; j < F(); j++)
				if (matrixx[i][j] > 0)
					s.append("[" + labelss[j].getName() + " , " + matrixx[i][j] + "] ");
		}
		return s.toString();
	}
    
    
    
    
    
}

    
    
    

