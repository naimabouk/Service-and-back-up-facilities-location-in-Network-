
package service.and.back.up.facilities;


public class Abstraction_Facility {
       private String name;
	private int maxDist;// the maximum allowable back up distance

	public Abstraction_Facility(String name , int maxDist  ) {
		this.name = name;
		this.maxDist = maxDist;

	}
	public  String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getMaxDist() {
		return maxDist;
	}

	public void setMaxDist(int maxDist) {
		this.maxDist = maxDist;
	}
    
}
